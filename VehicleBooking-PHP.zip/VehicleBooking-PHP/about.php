<!DOCTYPE html>
<html lang="en">

<?php include("vendor/inc/head.php");?>

<body>

  <!-- Navigation -->
  <?php include("vendor/inc/nav.php");?>

  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">About
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.php">Home</a>
      </li>
      <li class="breadcrumb-item active">About</li>
    </ol>

    <!-- Intro Content -->
     
    <div class="col">
      <div class="col-lg-9">
        <img class="img-fluid rounded mb-4" src="Frame4.jpg" alt="img not found">
      </div>
      <div class="col-lg">
        <center><h2>About Us</h2></center>
        <br>
        <p>
           <b> Electric Vehicle Booking System</b> is a system build to deal with problems faced in
            transportation. Major problems faced in this transport sector are such as task allocation,
            tracking of vehicles, assigning routes, payment, booking order, delivery report, generating
            transactions receipt, overworking of the employees, security of goods, users, drivers and also
            maintenance of the vehicles in terms of finance and time consumption. <b>E-Vehicle Booking System</b> 
            will be able to solve major problems such as task allocation where by a GPRS will
            be mounted in all vehicles and cab to ensure that each and every vehicle and cab is traced and
            assigned a tasks at a time, also keep track of all financial reports and expenses incurred in the
            organization by ensuring that all payments are made through credit/debit card or pay bill. The
            system will be able to have details of all the customers who has booked vehicle and also view
            the vehicles with tasks at hand and those without.
        </p>
        <br>
<center><h3>About Electric_Vehicle</h3></center>
<br>
        <p>An electric car, battery electric car, or all-electric car is an automobile that is propelled by one or more electric motors, 
          using only energy stored in batteries. Compared to internal combustion engine (ICE) vehicles, electric cars are quieter,
           have no exhaust emissions, and lower emissions overall.
           In the United States and the European Union, as of 2020, the total cost of ownership of recent electric vehicles is cheaper than
            that of equivalent ICE cars, due to lower fueling and maintenance costs.Charging an electric car can be done at a variety of charging stations; 
            these charging stations can be installed in both houses and public areas.</p>
      </div>
    </div>


    <!-- /.row -->
  </div>
  <!-- /.container -->

  <!-- Footer -->
<?php include("vendor/inc/footer.php");?>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
